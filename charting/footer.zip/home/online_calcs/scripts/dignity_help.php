<?php
  include ('../accesscontrol.php');

  if ($is_logged_in == False) { exit(); }

  include ('header_contest.html');

?>

  <br>
  
  <font size='2'>
    Essential dignity makes little difference in contest charts. It is accidental dignity that counts in contest horaries.<br><br>
    
    Anyway, essential dignity doesn't much concern us in these charts. Accidental dignity and receptions. Let me repeat: ACCIDENTAL DIGNITY and RECEPTIONS.<br><br>
    
    Any planet in major essential dignity is benefic.<br><br>
  </font>

<?php
  include ('footer.html');
?>
