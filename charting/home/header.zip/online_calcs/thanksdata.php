<?php
  include ('header.html');
?>

<div id='content'>
    <p><strong>Thank you for submitting birth data.    <br>
    <br><br>
    Click on what you would like to do next:<br>
    </strong><br>
    <font size='+1'><a href="scripts/data_entry_1.php">Add another person's birth data to your database</a></font><br><br>
    <br>
    <font size='+1'><a href="scripts/view_records.php">View your database entries</a></font></p>
  <p>&nbsp;</p>
</div>

<?php
  include ('footer.html');
?>

