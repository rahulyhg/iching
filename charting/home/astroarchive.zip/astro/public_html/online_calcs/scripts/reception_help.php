<?php
  include ('../accesscontrol.php');

  if ($is_logged_in == False) { exit(); }

  include ('header_contest.html');

?>

  <br>
  
  <font size='2'>
    In contest horaries, exaltation  is by far the strongest of all dignities. Therefore, it is by far the strongest of all receptions too. Stronger even than sign rulership.</b><br><br>
    
    For example, if Sun is ruler 1 and Saturn is ruler 7 and Saturn is in Aries and the Sun is in Gemini, then the Sun receives Saturn by exaltation (Saturn is in the Sun's exaltation sign) and thus has power over him.</b><br><br>
  </font>

<?php
  include ('footer.html');
?>
