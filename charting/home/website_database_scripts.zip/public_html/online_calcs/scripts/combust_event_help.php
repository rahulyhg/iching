<?php
  include ('../accesscontrol.php');

  if ($is_logged_in == False) { exit(); }

  include ('header_event.html');

?>

  <br>
  
  <font size='2'>
    Essential dignity makes no difference in event charts.<br><br>
    
    The orb for combustion is 2 degrees.<br><br>
  </font>

<?php
  include ('footer.html');
?>
