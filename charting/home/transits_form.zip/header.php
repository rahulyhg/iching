<html>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<TITLE>Astrological Transits by Allen Edwall</TITLE>
<META name="description" content="Generate your free natal horoscope report/interpretation">
<META name="keywords" content="free astrology programs, software, natal horoscope interpretations, Astro123, AstroWin, MatchMkr, relationships, composite, synastry, astrodynes, cosmodynes, transits, midpoints, keywords, Allen Edwall, study aids, charts">
<STYLE type='text/css'>
td
{
  FONT-SIZE: 12px; COLOR: #000000; FONT-FAMILY: Verdana, Arial, sans-serif; TEXT-DECORATION: none
}
</STYLE>
</HEAD>

<BODY TEXT="#000000" LINK="#0000FF" VLINK="#ff0000" bgcolor="#ffffff">

<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td>
      <center>
      <font size="6"><strong><font face="Arial">Astrological Transits</font></strong></font><br>
      </center>
    </td>
  </tr>
</table>

<br>

