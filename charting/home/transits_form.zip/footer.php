
<br><br>

<center>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td>
      <p align="center"><font face="Verdana"><b>Allen Edwall</b><br>
      </font></p>
      <p align="center"><font face="Verdana">All programs copyrighted<br>
      <br>
      </font>
      </p>
    </td>
  </tr>
</table>

</body>
</html>
